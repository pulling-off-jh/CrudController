@extends('admin.master')

@section('title')
    Show Product
@endsection

@section('body')

<div class="container">
    <div class="row">
        <div class="col-sm-6 mt-4 mx-auto">
            <h1 style="color:#ffffff; text-align: center;">All Products</h1>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-11 mt-4">
            <a href="{{route('product.create')}} "><div class="btn btn-info float-end">Create New Product</div></a>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-10 mx-auto mt-3">
            <h3 class="text-success text-center">{{session('message')}} </h3>
                <table class="table table-dark table-hover" style="border: 2px solid #584545;">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $product)
                        <tr>
                            <td>{{$loop->iteration}} </td>
                            <td>{{$product->name}} </td>
                            <td>{{$product->price}} </td>
                            <td>{{$product->image}} </td>
                            <td>
                                <a href="{{route('product.edit', ['id'=>$product->id])}} " class="btn btn-primary btn-sm">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <a href="{{route('product.delete', ['id'=>$product->id])}}" class="btn btn-danger btn-sm">
                                    <i class="far fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>

                </table>

        </div>
    </div>
</div>


@endsection
