@extends('admin.master')

@section('title')
    Create Product
@endsection

@section('body')

<div class="container">
    <div class="row">
        <div class="col-sm-6 mt-4 mx-auto">
            <h1 style="color:#ffffff; text-align: center;">Create Product</h1>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-9 mt-4">
            <a href="{{route('product.home')}} "><div class="btn btn-info float-end" >View All Products</div></a>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <h3 class="text-success text-center">{{session('message')}} </h3>
            <form action="{{route('product.store')}} " method="POST" enctype="multipart/form-data" style="color:#ffffff;">
                @csrf
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter Name" name="name">
                    @if ($errors->has('name'))
                    {
                      <span class="text-danger">{{ $errors->first('name') }}</span>
                    }
                    @endif
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Product Price</label>
                    <input type="number" class="form-control" id="pwd" placeholder="Enter Price" name="price">
                    @if ($errors->has('price'))
                    {
                      <span class="text-danger">{{ $errors->first('price') }}</span>
                    }
                    @endif
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Product Image</label>
                    <input type="file" class="form-control" id="pwd" placeholder="Enter Image" name="image">
                    @if ($errors->has('image'))
                    {
                      <span class="text-danger">{{ $errors->first('image') }}</span>
                    }
                    @endif
                </div>
                <button type="submit" class="btn btn-success">Create Product</button>
            </form>
        </div>
    </div>
</div>

@endsection
