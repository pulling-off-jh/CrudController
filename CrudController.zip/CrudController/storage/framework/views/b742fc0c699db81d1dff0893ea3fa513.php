<?php $__env->startSection('title'); ?>
    Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <form action="<?php echo e(route('product.store')); ?> " method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Name</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter Name" name="name">
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Price</label>
                    <input type="number" class="form-control" id="pwd" placeholder="Enter Price" name="price">
                </div>
                <div class="mb-3">
                    <input type="file" class="form-control" id="pwd" placeholder="Enter Image" name="image">
                </div>
                <button type="submit" class="btn btn-primary">Create Product</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL10\MicroDeftLTD\deft-micro\resources\views/admin/product/create.blade.php ENDPATH**/ ?>