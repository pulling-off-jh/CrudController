<?php $__env->startSection('title'); ?>
    Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-6 mt-4 mx-auto">
            <h1 style="color:#ffffff; text-align: center;">Update Product</h1>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <form action="<?php echo e(route('product.update', $product->id)); ?> " method="POST" enctype="multipart/form-data" style="color:#ffffff;">
                <?php echo csrf_field(); ?>
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Name</label>
                    <input type="text" class="form-control" value="<?php echo e($product->name); ?> " id="email" placeholder="Enter Name" name="name">
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Price</label>
                    <input type="number" class="form-control" value="<?php echo e($product->price); ?> " id="pwd" placeholder="Enter Price" name="price">
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Image</label>
                    <input type="file" class="form-control" id="pwd" placeholder="Enter Image" name="image">
                </div>
                <button type="submit" class="btn btn-primary">Update Product</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL10\CrudController\deft-micro\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>