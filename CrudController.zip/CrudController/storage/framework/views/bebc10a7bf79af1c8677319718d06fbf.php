<?php $__env->startSection('title'); ?>
    Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-6 mt-4 mx-auto">
            <h1 style="color:#ffffff; text-align: center;">Create Product</h1>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-9 mt-4">
            <a href="<?php echo e(route('product.home')); ?> "><div class="btn btn-info float-end" >View All Products</div></a>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <h3 class="text-success text-center"><?php echo e(session('message')); ?> </h3>
            <form action="<?php echo e(route('product.store')); ?> " method="POST" enctype="multipart/form-data" style="color:#ffffff;">
                <?php echo csrf_field(); ?>
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter Name" name="name">
                    <?php if($errors->has('name')): ?>
                    {
                      <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    }
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Product Price</label>
                    <input type="number" class="form-control" id="pwd" placeholder="Enter Price" name="price">
                    <?php if($errors->has('price')): ?>
                    {
                      <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                    }
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="pwd" class="form-label">Product Image</label>
                    <input type="file" class="form-control" id="pwd" placeholder="Enter Image" name="image">
                    <?php if($errors->has('image')): ?>
                    {
                      <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                    }
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success">Create Product</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL10\CrudController\deft-micro\resources\views/admin/product/create.blade.php ENDPATH**/ ?>