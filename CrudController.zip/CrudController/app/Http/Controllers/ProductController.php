<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index(){
        // $products = Product::all();
        // return view('admin.product.index', ['products' => $products]);
        // return view('admin.product.index', compact('products'));
        return view('admin.product.index', ['products'=>Product::all()]);
    }

    public function create(){
        return view('admin.product.create');
    }

    public function store(Request $request){

        $request->validate([
            'name' => 'required',
            'price' => 'required',
            'image' => 'required'
        ]);

        //upload image
        $imageName = time().'.'.$request->image->extension();
        $request->image->move(public_path('product_img'), $imageName);

        //Save to database
        $product = new Product;
        $product->name = $request->name;
        $product->price = $request->price;
        $product->image = $imageName;
        $product->save();

        return redirect()->route('product.create')->with('message', 'Product Created Successfully');

        // Product::create($request->all());

        // $product = new Product;
        // $product->name = $request->name;
        // $product->price = $request->price;
        // $product->image = $request->image;.
        // $product->save();
    }

    public function edit($id){
        // return view('admin.product.edit', ['product'=>Product::find($id)]);

        $product = Product::where('id',$id)->first();
        return view('admin.product.edit',[
            'product' => $product
        ]);
    }

    public function update(Request $request, $id){
        $product = Product::find($id);

        $product->name = $request->name;
        $product->price = $request->price;
        $product->image = $request->image;
        $product->save();

        return redirect('/')->with('message', 'Product updated successfully');
    }

    public function delete($id){
        $product = Product::where('id', $id)->first();

        $product->delete();

        return back()->with('message', 'Product Deleted');
    }
}
